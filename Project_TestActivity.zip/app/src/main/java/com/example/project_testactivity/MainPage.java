package com.example.project_testactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        final TextView text = findViewById(R.id.result);
        final Button clear = findViewById(R.id.btn_clear);
        final Button btn0 = findViewById(R.id.btn0);
        final Button btn1 = findViewById(R.id.btn1);
        final Button btn2 = findViewById(R.id.btn2);
        final Button btn3 = findViewById(R.id.btn3);
        final Button btn4 = findViewById(R.id.btn4);
        final Button btn5 = findViewById(R.id.btn5);
        final Button btn6 = findViewById(R.id.btn6);
        final Button btn7 = findViewById(R.id.btn7);
        final Button btn8 = findViewById(R.id.btn8);
        final Button btn9 = findViewById(R.id.btn9);
        final Button btn_result = findViewById(R.id.btn_result);
        final Button btn_plus = findViewById(R.id.btn_plus);
        final Button btn_minus = findViewById(R.id.btn_minus);
        final Button btn_mul = findViewById(R.id.btn_mul);
        final Button btn_div = findViewById(R.id.btn_div);

        View.OnClickListener btn_num = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if((text.getText().toString().equals("0")) && (text.getText().toString().length() == 1)){
                    text.setText("");
                }
                if(view == btn0){
                    text.setText(text.getText().toString()+0);
                }
                if(view == btn1){
                    text.setText(text.getText().toString()+1);
                }
                if(view == btn2){
                    text.setText(text.getText().toString()+2);
                }
                if(view == btn3){
                    text.setText(text.getText().toString()+3);
                }
                if(view == btn4){
                    text.setText(text.getText().toString()+4);
                }
                if(view == btn5){
                    text.setText(text.getText().toString()+5);
                }
                if(view == btn6){
                    text.setText(text.getText().toString()+6);
                }
                if(view == btn7){
                    text.setText(text.getText().toString()+7);
                }
                if(view == btn8){
                    text.setText(text.getText().toString()+8);
                }
                if(view == btn9){
                    text.setText(text.getText().toString()+9);
                }
            }
        };
        btn0.setOnClickListener(btn_num);
        btn1.setOnClickListener(btn_num);
        btn2.setOnClickListener(btn_num);
        btn3.setOnClickListener(btn_num);
        btn4.setOnClickListener(btn_num);
        btn5.setOnClickListener(btn_num);
        btn6.setOnClickListener(btn_num);
        btn7.setOnClickListener(btn_num);
        btn8.setOnClickListener(btn_num);
        btn9.setOnClickListener(btn_num);

        View.OnClickListener symbol = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String input = text.getText().toString().substring(text.getText().length()-1, text.getText().length());
                if(!input.equals("+")){
                    if(!input.equals("-")){
                        if(!input.equals("*")){
                            if(!input.equals("/")){
                                if(view == btn_plus){
                                    text.setText(text.getText().toString()+"+");
                                }
                                if(view == btn_minus){
                                    text.setText(text.getText().toString()+"-");
                                }
                                if(view == btn_mul){
                                    text.setText(text.getText().toString()+"*");
                                }
                                if(view == btn_div){
                                    text.setText(text.getText().toString()+"/");
                                }
                            }
                        }
                    }
                }
            }
        };
        btn_plus.setOnClickListener(symbol);
        btn_minus.setOnClickListener(symbol);
        btn_mul.setOnClickListener(symbol);
        btn_div.setOnClickListener(symbol);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setText("0");
            }
        });
        btn_result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//연산 기호의 우선 순위 없이 계산합니다.
                int prev = 0;
                int current = 0;
                char sign = 'a';
                boolean first = true;
                String temp2 = text.getText().toString();
                for(int i=0; i < temp2.length(); i++){
                    char temp = temp2.charAt(i);

                    if(Character.isDigit(temp)){
                        current *= 10;
                        current += temp - '0';
                    }else{
                        if(first){
                            if(temp == '+'){
                                sign = '+';
                            }
                            if(temp == '-'){
                                sign = '-';
                            }
                            if(temp == '*'){
                                sign = '*';
                            }
                            if(temp == '/'){
                                sign = '/';
                            }
                            prev = current;
                            current = 0;
                            first = false;
                        }else{
                            if(temp == '+'){
                                prev += current;
                                sign = '+';
                            }
                            if(temp == '-'){
                                prev -= current;
                                sign = '-';
                            }
                            if(temp == '*'){
                                prev *= current;
                                sign = '*';
                            }
                            if(temp == '/'){
                                prev /= current;
                                sign = '/';
                            }
                            current = 0;
                        }
                    }
                }
                if(sign == '+'){
                    prev += current;
                }else if(sign == '-'){
                    prev -= current;
                }else if(sign == '*'){
                    prev *= current;
                }else if(sign == '/'){
                    prev /= current;
                }else if(sign == 'a'){
                    prev = current;
                }
                text.setText(Integer.toString(prev));
            }
        });
    }
}
