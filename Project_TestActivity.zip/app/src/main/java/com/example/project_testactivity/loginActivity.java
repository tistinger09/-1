package com.example.project_testactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class loginActivity extends Activity {
    ArrayList<String> id_list = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button btn_login = (Button) findViewById(R.id.btn_login);
        Button btn_join = (Button) findViewById(R.id.btn_join);
        final File directory = new File(getFilesDir()+"/login");

        btn_join.setOnClickListener(new View.OnClickListener() { //회원가입 버튼을 클릭한 경우
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), register_page.class); //회원가입 페이지로 넘어갑니다
                startActivity(intent);
            }
        });
        btn_login.setOnClickListener(new View.OnClickListener(){ //로그인 버튼을 클릭한 경우
            @Override
            public void onClick(View view){
                fileCheck(directory); //info.txt에서 id들을 불러옵니다.
                EditText id = (EditText) findViewById(R.id.in_id); //사용자가 입력한 아이디를 불러옵니다.
                boolean exists = false; //id가 존재하는지 체크합니다. false = 존재하지 않음
                for(int i=0; i<id_list.size(); i++){
                  if(id.getText().toString().equals(id_list.get(i))){ //id 리스트와 사용자 입력을 비교합니다.
                      exists = true;
                  }
                }
                if(!exists){ //id가 존재하지 않는 경우
                    Toast.makeText(getApplicationContext(), "존재하지 않는 id입니다", Toast.LENGTH_LONG).show();
                }else{ //id가 존재하는 경우
                    try{ //비밀번호가 일치하는지 확인합니다.
                        BufferedReader text = new BufferedReader(new FileReader(directory+"/"+id.getText()+".txt"));
                        String temp = text.readLine(); //비밀번호를 읽어옵니다.
                        if(temp != null){
                            EditText pw = (EditText) findViewById(R.id.in_pw);
                            if(pw.getText().toString().equals(temp)){
                                Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(getApplicationContext(), MainPage.class); //회원가입 페이지로 넘어갑니다
                                startActivity(intent);
                            }else{
                                Toast.makeText(getApplicationContext(), "비밀번호가 틀립니다", Toast.LENGTH_LONG).show();
                            }
                        }
                    }catch (IOException e){
                        e.printStackTrace();
                    }
                }

            }
        });
    }


    public void fileCheck(File directory){
        if(!directory.exists()){ //디렉토리가 존재하지 않는 경우 디렉토리를 생성하고 admin 아이디를 생성합니다.
            directory.mkdir();
            try{
                BufferedWriter text = new BufferedWriter(new FileWriter(directory+"/info.txt", false));
                BufferedWriter infomation = new BufferedWriter(new FileWriter(directory+"/admin.txt", false));
                text.write("admin\n");
                text.flush();
                text.close();
                infomation.write("0000\n");
                infomation.write("이름\n");
                infomation.write("주소\n");
                infomation.write("전화번호");
                infomation.flush();
                infomation.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        try{//info.txt에서 아이디들을 읽은뒤 id_list에 저장합니다.
            BufferedReader text = new BufferedReader(new FileReader(directory+"/info.txt"));
            String temp;
            while((temp = text.readLine()) != null){
                id_list.add(temp);
            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }


}
