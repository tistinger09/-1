package com.example.project_testactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class register_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        final EditText in_password = (EditText) findViewById(R.id.in_reg_pw);
        final EditText in_id = (EditText) findViewById(R.id.in_reg_id);
        final EditText in_name = (EditText) findViewById(R.id.in_name);
        final EditText in_tel = (EditText) findViewById(R.id.in_tel);
        final EditText in_address = (EditText) findViewById(R.id.in_address);
        final TextView pw_status = (TextView) findViewById(R.id.text_pw_status);
        final TextView in_status = (TextView) findViewById(R.id.text_id_status);
        final Button register = (Button) findViewById(R.id.btn_register);
        final RadioButton radio_yes = (RadioButton) findViewById(R.id.radio_yes);
        final RadioButton radio_no = (RadioButton) findViewById(R.id.radio_no);
        final ArrayList<String> id_list = new ArrayList<String>();
        final File directory = new File(getFilesDir()+"/login");
        try{
            BufferedReader text = new BufferedReader(new FileReader(directory+"/info.txt"));
            String temp;
            while((temp = text.readLine()) != null){
                id_list.add(temp);
            }
        }catch (IOException e){
            e.printStackTrace();
        }
        radio_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(radio_no.isChecked()){
                    radio_no.setChecked(false);
                }
            }
        });
        radio_no.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(radio_yes.isChecked()){
                    radio_yes.setChecked(false);
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                boolean check_id = false;
                boolean check_pw = false;
                boolean check_radio = false;
                if(in_status.getText().toString().equals("사용 가능한 아이디 입니다.")){
                    check_id = true;
                }
                if(pw_status.getText().toString().equals("사용 가능한 비밀번호입니다.")){
                    check_pw = true;
                }
                if(radio_yes.isChecked()){
                    check_radio = true;
                }
                if(check_id && check_pw) {
                    if(check_radio){
                        try {
                            BufferedWriter text = new BufferedWriter(new FileWriter(directory + "/info.txt", true));
                            BufferedWriter infomation = new BufferedWriter(new FileWriter(directory + "/"+in_id.getText().toString()+".txt", false));
                            text.write(in_id.getText().toString()+"\n");
                            text.flush();
                            text.close();
                            infomation.write(in_password.getText().toString()+"\n");
                            infomation.write(in_name.getText().toString()+"\n");
                            infomation.write(in_address.getText().toString()+"\n");
                            infomation.write(in_tel.getText().toString()+"\n");
                            infomation.flush();
                            infomation.close();
                            register_page.super.onBackPressed();
                        }catch (IOException e){

                        }
                    }else{
                        Toast.makeText(getApplicationContext(), "사용 약관에 동의해주세요", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 확인해 주세요", Toast.LENGTH_LONG).show();
                }
            }
        });
        in_id.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void afterTextChanged(Editable editable) {
                boolean check = false;
                for(int i=0; i<id_list.size(); i++){
                    if(in_id.getText().toString().equals(id_list.get(i))){
                        check = true;
                    }
                }
                if(check){
                    in_status.setText( "중복된 아이디 입니다.");
                }else{
                    in_status.setText("사용 가능한 아이디 입니다.");
                }
            }
        });
        in_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void afterTextChanged(Editable editable) {
                int len = editable.length();
                if(len < 6 || len >15){
                    pw_status.setText("비밀번호는 6자 이상 15자 이하여야 합니다.");
                }else{
                    pw_status.setText("");
                    boolean upper = false;
                    boolean lower = false;
                    boolean special = false;
                    boolean num = false;
                    for(int i=0; i<len; i++){
                        if(Character.isUpperCase(editable.charAt(i))){
                            upper = true;
                        }else if(Character.isLowerCase(editable.charAt(i))){
                            lower = true;
                        }else if(Character.isDigit(editable.charAt(i))){
                            num = true;
                        }else{
                            special = true;
                        }
                    }
                    if(!((upper && lower) && (num && special))){
                        pw_status.setText("비밀번호에는 반드시 대문자, 소문자, 숫자 그리고 특수문자가 들어가야 합니다.");
                    }else{
                        pw_status.setText("사용 가능한 비밀번호입니다.");
                    }
                }
            }
        });

    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
    }
}
